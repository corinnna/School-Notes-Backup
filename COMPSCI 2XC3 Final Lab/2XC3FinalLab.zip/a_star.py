import min_heap

# graph implementation
class DirectedWeightedGraph:

    def __init__(self, n):
        self.adj = {}
        self.weights = {}
        for i in range(n):
            self.adj[i] = []

    def are_connected(self, node1, node2):
        for neighbour in self.adj[node1]:
            if neighbour == node2:
                return True
        return False

    def adjacent_nodes(self, node):
        return self.adj[node]

    def add_node(self, node):
        self.adj[node] = []

    def add_edge(self, node1, node2, weight):
        if node2 not in self.adj[node1]:
            self.adj[node1].append(node2)
        self.weights[(node1, node2)] = weight

    def w(self, node1, node2):
        if self.are_connected(node1, node2):
            return self.weights[(node1, node2)]

    def number_of_nodes(self):
        return len(self.adj)


#a_star implementation
def a_star(G,s,d,h):
    # marked keeps track of all marked nodes
    # dist keeps track of the shortest distance to each node
    # pred keeps track of the predecessor of each node
    marked, dist, pred = {}, {}, {}

    # initialize our minimum heap
    Q = min_heap.MinHeap([])
    for i in range(G.number_of_nodes()):
        # initialize all nodes to unmarked
        marked[i] = False

        # set the distance to each node as infinity
        dist[i] = float("inf")

        # insert all nodes into the heap
        Q.insert(min_heap.Element(i, float("inf")))

    # decrease our starting node's "cost" to 0 since it is our starting node
    # in this case, cost = distance to node + heuristic value
    Q.decrease_key(s, 0)

    # decrease our starting node's distance to 0
    dist[s] = 0

    # continue until we find our shortest past to d or until all nodes are checked
    while not (Q.is_empty() or marked[d]):
        # get node at the end of our current path
        current_node = Q.extract_min().value

        # mark that node as true since we will have checked all adjacent nodes for this node
        marked[current_node] = True

        # check all nodes adjacent to our current node
        for neighbour in G.adj[current_node]:
            # get the edge weight
            edge_weight = G.w(current_node, neighbour)
            # get the heuristic for this adjacent node
            heuristic = h[neighbour]

            # if our adjacent node hasn't had all its adjacent nodes checked
            if not marked[neighbour]:
                # if the distance from our current node to the adjacent node is less than the previous shortest adjacent node's path
                if dist[current_node] + edge_weight < dist[neighbour]:
                    # set this as the new shortest distance
                    dist[neighbour] = dist[current_node] + edge_weight
                    # decrease the adjacent node's cost (remember this includes the heuristic)
                    Q.decrease_key(neighbour, dist[neighbour] + heuristic)
                    # store the current node as the neighbour's predecessor
                    pred[neighbour] = current_node

    # the following snippet essentially traverses from the end node to our starting node

    # current_point represents the node we are currently at (starts at our end node)
    current_point = d

    # current_pred represents the predecessor of our current node
    current_pred = pred[d]

    # predecessors for our shortest path
    pred2 = {}

    # continue traversing until our predecessor is our start node
    while current_pred != s:
        # add the current node's predecessor
        pred2[current_point] = current_pred
        # make the current node its predecessor (so we traverse towards our start node)
        current_point = current_pred
        # make the predecessor our current node's predecessor
        current_pred = pred[current_pred]
    
    # add the pred that connects to our start node
    pred2[current_point] = s

    # returns the predecessor in the form (node: predecessor) and the shortest path/distance
    return (pred2, dist[d])

# testing graph

g3 = DirectedWeightedGraph(13)
g3.add_edge(0,1,7)
g3.add_edge(1,0,7)
g3.add_edge(0,2,2)
g3.add_edge(2,0,2)
g3.add_edge(1,2,3)
g3.add_edge(2,1,3)
g3.add_edge(1,4,4)
g3.add_edge(4,1,4)
g3.add_edge(2,4,4)
g3.add_edge(4,2,4)
g3.add_edge(2,6,1)
g3.add_edge(6,2,1)
g3.add_edge(4,5,5)
g3.add_edge(5,4,5)
g3.add_edge(5,6,3)
g3.add_edge(6,5,3)
g3.add_edge(6,7,2)
g3.add_edge(7,6,2)
g3.add_edge(7,8,2)
g3.add_edge(8,7,2)
g3.add_edge(0,3,3)
g3.add_edge(3,0,3)
g3.add_edge(3,9,2)
g3.add_edge(9,3,2)
g3.add_edge(9,10,4)
g3.add_edge(10,9,4)
g3.add_edge(9,11,4)
g3.add_edge(11,9,4)
g3.add_edge(10,11,6)
g3.add_edge(11,10,6)
g3.add_edge(10,12,4)
g3.add_edge(12,10,4)
g3.add_edge(11,12,4)
g3.add_edge(12,11,4)
g3.add_edge(12,8,5)
g3.add_edge(8,12,5)

# heuristic for temporary graph
h = {0:10, 1:9, 2:7, 3:8, 4:8, 5:6, 6:6, 7:3, 8:0, 9:6, 10:4, 11:4, 12:3}