import min_heap

class DirectedWeightedGraph:

    def __init__(self, n):
        self.adj = {}
        self.weights = {}
        for i in range(n):
            self.adj[i] = []

    def are_connected(self, node1, node2):
        for neighbour in self.adj[node1]:
            if neighbour == node2:
                return True
        return False

    def adjacent_nodes(self, node):
        return self.adj[node]

    def add_node(self, node):
        self.adj[node] = []

    def add_edge(self, node1, node2, weight):
        if node2 not in self.adj[node1]:
            self.adj[node1].append(node2)
        self.weights[(node1, node2)] = weight

    def w(self, node1, node2):
        if self.are_connected(node1, node2):
            return self.weights[(node1, node2)]

    def number_of_nodes(self):
        return len(self.adj)



def dijkstra(G,s,d):
    marked, dist = {}, {}
    Q = min_heap.MinHeap([])
    for i in range(G.number_of_nodes()):
        marked[i] = False
        dist[i] = float("inf")
        Q.insert(min_heap.Element(i, float("inf")))

    Q.decrease_key(s, 0)
    dist[s] = 0

    while not (Q.is_empty() or marked[d]):
        current_node = Q.extract_min().value
        marked[current_node] = True
        print("current node popped: ", current_node)
        for neighbour in G.adj[current_node]:
            edge_weight = G.w(current_node, neighbour)
            if not marked[neighbour]:
                if dist[current_node] + edge_weight < dist[neighbour]:
                    dist[neighbour] = dist[current_node] + edge_weight
                    Q.decrease_key(neighbour, dist[neighbour])

    return dist[d]









g= DirectedWeightedGraph(5)

g.add_edge(0,1,35)
g.add_edge(1,0,35)
g.add_edge(0,2,15)
g.add_edge(2,0,15)
g.add_edge(0,3,25)
g.add_edge(3,0,25)
g.add_edge(1,2,15)
g.add_edge(2,1,15)
g.add_edge(1,4,5)
g.add_edge(4,1,5)
g.add_edge(2,3,35)
g.add_edge(3,2,35)
g.add_edge(2,4,5)
g.add_edge(4,2,5)
g.add_edge(3,4,20)
g.add_edge(4,3,20)

g2 = DirectedWeightedGraph(5)
g2.add_edge(0,1,10)
g2.add_edge(0,2,15)
g2.add_edge(0,3,25)
g2.add_edge(3,4,20)
g2.add_edge(4,1,-40)
g2.add_edge(4,2,-35)
g2.add_edge(3,2,35)

g3 = DirectedWeightedGraph(13)
g3.add_edge(0,1,7)
g3.add_edge(1,0,7)
g3.add_edge(0,2,2)
g3.add_edge(2,0,2)
g3.add_edge(1,2,3)
g3.add_edge(2,1,3)
g3.add_edge(1,4,4)
g3.add_edge(4,1,4)
g3.add_edge(2,4,4)
g3.add_edge(4,2,4)
g3.add_edge(2,6,1)
g3.add_edge(6,2,1)
g3.add_edge(4,5,5)
g3.add_edge(5,4,5)
g3.add_edge(5,6,3)
g3.add_edge(6,5,3)
g3.add_edge(6,7,2)
g3.add_edge(7,6,2)
g3.add_edge(7,8,2)
g3.add_edge(8,7,2)
g3.add_edge(0,3,3)
g3.add_edge(3,0,3)
g3.add_edge(3,9,2)
g3.add_edge(9,3,2)
g3.add_edge(9,10,4)
g3.add_edge(10,9,4)
g3.add_edge(9,11,4)
g3.add_edge(11,9,4)
g3.add_edge(10,11,6)
g3.add_edge(11,10,6)
g3.add_edge(10,12,4)
g3.add_edge(12,10,4)
g3.add_edge(11,12,4)
g3.add_edge(12,11,4)
g3.add_edge(12,8,5)
g3.add_edge(8,12,5)