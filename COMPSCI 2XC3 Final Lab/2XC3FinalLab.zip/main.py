class ShortPathFinder:
	def __init__(self):
		self.algorithm = SPAlgorithm()
		self.graph = Graph()
	
	def calc_short_path(self, source: int, dest: int) -> float:
		return self.algorithm.calc_sp(self.graph, source, dest)
		
	def set_graph(self, graph: Graph):
		self.graph = graph
		
	def set_algorithm(self, algorithm: SPAlgorithm):
		self.algorithm = algorithm 

#interface
class SPAlgorithm:
	def calc_sp(graph: Graph, source: int, dest: int) -> float:
		pass

#interface
class Graph:
	def get_adj_nodes(node: int) -> List[int]:
		pass
		
	def add_node(node: int):
		pass  

	def add_edge(start: int, end: int, w: float):
		pass 

	def get_num_of_nodes() -> int:
		pass 
	
	def w(node1: int, node2: int) -> float: 
		pass

#concrete class for SPAlgorithm
class Dijkstra(SPAlgorithm):
  def calc_sp(graph: Graph, source: int, dest: int) -> float:
    return dijkstra(Graph, source)[dest]

  def dijkstra(G, source):
    pred = {} #Predecessor dictionary. Isn't returned, but here for your understanding
    dist = {} #Distance dictionary
    Q = min_heap.MinHeap([])
    nodes = list(G.adj.keys())

    #Initialize priority queue/heap and distances
    for node in nodes:
        Q.insert(min_heap.Element(node, float("inf")))
        dist[node] = float("inf")
    Q.decrease_key(source, 0)

    #Meat of the algorithm
    while not Q.is_empty():
        current_element = Q.extract_min()
        current_node = current_element.value
        dist[current_node] = current_element.key
        for neighbour in G.adj[current_node]:
            if dist[current_node] + G.w(current_node, neighbour) < dist[neighbour]:
                Q.decrease_key(neighbour, dist[current_node] + G.w(current_node, neighbour))
                dist[neighbour] = dist[current_node] + G.w(current_node, neighbour)
                pred[neighbour] = current_node
    return dist

class BellmanFord(SPAlgorithm):
	def calc_sp(graph: Graph, source: int, dest: int) -> float:
		return bellmanford(Graph, source)[dest]
	
	def bellman_ford(G, source):
    pred = {} #Predecessor dictionary. Isn't returned, but here for your understanding
    dist = {} #Distance dictionary
    nodes = list(G.adj.keys())

    #Initialize distances
    for node in nodes:
        dist[node] = float("inf")
    dist[source] = 0

    #Meat of the algorithm
    for _ in range(G.number_of_nodes()):
        for node in nodes:
            for neighbour in G.adj[node]:
                if dist[neighbour] > dist[node] + G.w(node, neighbour):
                    dist[neighbour] = dist[node] + G.w(node, neighbour)
                    pred[neighbour] = node
    return dist

class AStar(SPAlgorithm):
  
  def calc_sp(graph: Graph, source: int, dest: int) -> float:
		return a_star(Graph, source, dest, Graph.get_heuristic())

  def a_star(G,s,d,h):
    # marked keeps track of all marked nodes
    # dist keeps track of the shortest distance to each node
    # pred keeps track of the predecessor of each node
    marked, dist, pred = {}, {}, {}

    # initialize our minimum heap
    Q = min_heap.MinHeap([])
    for i in range(G.number_of_nodes()):
        # initialize all nodes to unmarked
        marked[i] = False

        # set the distance to each node as infinity
        dist[i] = float("inf")

        # insert all nodes into the heap
        Q.insert(min_heap.Element(i, float("inf")))

    # decrease our starting node's "cost" to 0 since it is our starting node
    # in this case, cost = distance to node + heuristic value
    Q.decrease_key(s, 0)

    # decrease our starting node's distance to 0
    dist[s] = 0

    # continue until we find our shortest past to d or until all nodes are checked
    while not (Q.is_empty() or marked[d]):
        # get node at the end of our current path
        current_node = Q.extract_min().value

        # mark that node as true since we will have checked all adjacent nodes for this node
        marked[current_node] = True

        # check all nodes adjacent to our current node
        for neighbour in G.adj[current_node]:
            # get the edge weight
            edge_weight = G.w(current_node, neighbour)
            # get the heuristic for this adjacent node
            heuristic = h[neighbour]

            # if our adjacent node hasn't had all its adjacent nodes checked
            if not marked[neighbour]:
                # if the distance from our current node to the adjacent node is less than the previous shortest adjacent node's path
                if dist[current_node] + edge_weight < dist[neighbour]:
                    # set this as the new shortest distance
                    dist[neighbour] = dist[current_node] + edge_weight
                    # decrease the adjacent node's cost (remember this includes the heuristic)
                    Q.decrease_key(neighbour, dist[neighbour] + heuristic)
                    # store the current node as the neighbour's predecessor
                    pred[neighbour] = current_node

    # the following snippet essentially traverses from the end node to our starting node

    # current_point represents the node we are currently at (starts at our end node)
    current_point = d

    # current_pred represents the predecessor of our current node
    current_pred = pred[d]

    # predecessors for our shortest path
    pred2 = {}

    # continue traversing until our predecessor is our start node
    while current_pred != s:
        # add the current node's predecessor
        pred2[current_point] = current_pred
        # make the current node its predecessor (so we traverse towards our start node)
        current_point = current_pred
        # make the predecessor our current node's predecessor
        current_pred = pred[current_pred]
    
    # add the pred that connects to our start node
    pred2[current_point] = s

    # returns the predecessor in the form (node: predecessor) and the shortest path/distance
    return (pred2, dist[d])

class WeightedGraph(Graph):
	def __init__(self):
        self.adj = {}
        self.weights = {}

    def get_adj_nodes(self, node):
        return self.adj[node]

    def add_node(self, node):
        self.adj[node] = []

    def add_edge(self, node1, node2, weight):
        if node2 not in self.adj[node1]:
            self.adj[node1].append(node2)
        self.weights[(node1, node2)] = weight

    def get_num_of_nodes(self):
        return len(self.adj)

		def w(self, node1, node2):
        return self.weights[(node1, node2)]

class HeuristicGraph(WeightedGraph):  
	def __init__(self, h: Dict[int, float]):
        self.__heuristic = h

    def get_heuristic(self):
        return self.__heuristic