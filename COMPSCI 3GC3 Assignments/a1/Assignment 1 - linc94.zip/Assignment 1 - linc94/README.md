My screen recorder is broken. The colour has a yellowish tint causing colour differences.

If I set inc to 1/24, it spins really fast, so i have attached two versions, one that is normal, and one that is slowed.